"# Ford Gobike Data Exploration"

"## By: Maha Abdallah "

"### the project explaining "

"this project is used to explore the date base  of the ford gobike systems and come out with the best exploration findings and variables throughout using python library and its associated . The document contains dataset some 183,412 and sixteen object The project is investigation mistreatment 2 steps.",
"1.to explore the date base  of the ford gobike systems and come out with the best exploration findings and variables throughout using python library and its associated .
"2. my findings come from instructive technique. The instructive this technique is extremely vital is employed throughout and when {the information|the info|the information} wrangle method and it facilitate patterns and relationships within the data. It facilitate in home reserve applied mathematics analysis and find conclusions and",

"### project details "

"Continue the dataset of ford gobike",

"Go through the information",

"use the dataset that are available  to research and come up with the  finding "

"### project findings "

"subscribers ride in the summer season more than cold season. subscribers used the system heavily on work days focused around 7-9am and 17-18pm for work commute, whereas customers ride heaps over weekends and within the afternoon for leisure/touring functions. Subscribers attended have abundant shorter/quicker visits compared to customers that makes subscriber usage a lot of economical. each client and Subscriber square measure showing similar trends for age and trip period, except for subscribers the trip period is higher for older age."

"### presentation "

" We found out that a lot of subscribers using the bike sharing system especially in summer seasons more than the winter  the casual customers ride least than the subscribers . subscribers used the system heavily on work days focused around 7-9am and 17-18pm for work commute, whereas customers ride heaps over weekends and within the afternoon for leisure/touring functions. Subscribers attended have abundant shorter/quicker visits compared to customers that makes subscriber usage a lot of economical. each client and Subscriber square measure showing similar trends for age and trip period, except for subscribers the trip period is higher for older age."

"### Files"

"readme.md - this file is to summarize my step and  my finding.",
"exploration_template.ipynb -to put my variable exploration in organizing and easy way to understand .",
"slide_deck_template.ipynb - I will used it to show my slide deck in organizations way.",
"output_toggle.tpl -I will use this  This guide file with bconvert to export my slide deck.